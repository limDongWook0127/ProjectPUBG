// Fill out your copyright notice in the Description page of Project Settings.


#include "Interface/InteractInterface.h"

// Add default functionality here for any IInteractInterface functions that are not pure virtual.
UTexture2D* IInteractInterface::SetKeyTexture()
{
	// DefaultKeyTexture = LoadObject<UTexture2D>(nullptr, TEXT("/Game/PUBGAsset/UI/KeyboardAndMouse/Keys/Key_Char_F.Key_Char_F"));
	// return DefaultKeyTexture;

	return nullptr;
}
