// Fill out your copyright notice in the Description page of Project Settings.


#include "Item/BaseItem.h"


ABaseItem::ABaseItem()
{
	PrimaryActorTick.bCanEverTick = false;
}
