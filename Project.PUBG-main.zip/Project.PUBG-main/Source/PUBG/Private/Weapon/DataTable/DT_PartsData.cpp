// Fill out your copyright notice in the Description page of Project Settings.


#include "Weapon/DataTable/DT_PartsData.h"

FPartsData::FPartsData()
{
	TypeName = "";
	GunName = "";
	ChangedValues = 0.0f;
	AttachParts_SocketName = "";
	Parts_StaticMesh = nullptr;
}
