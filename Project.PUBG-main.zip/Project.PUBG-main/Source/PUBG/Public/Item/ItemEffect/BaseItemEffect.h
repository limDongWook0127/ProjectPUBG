// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Item/ItemBase.h"
#include "BaseItemEffect.generated.h"

/**
 * 
 */
UCLASS()
class PUBG_API ABaseItemEffect : public AItemBase
{
	GENERATED_BODY()
	
};
