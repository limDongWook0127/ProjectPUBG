// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Weapon/Guns/Gun_Base.h"
#include "AK_47.generated.h"

/**
 * 
 */
UCLASS()
class PUBG_API AAK_47 : public AGun_Base
{
	GENERATED_BODY()
	public:
	AAK_47();
	
};
